import socketio
sio = socketio.Client()
provider_id = "VLAB_CONNECTOR"

def run():
    return "run done"



@sio.event
def connect():
    print('connected to server')
    sio.emit("register_provider", {
        "provider_id": provider_id,
        "name": provider_id
    });

@sio.event
def new_request(data):
    print('new_request')
    if data["cmd"] == "run":
        sio.emit("provider_reply", {
            **data,
            "result": "run started"
        })
        return
    sio.emit("provider_reply", {
            **data,
            "result": f"cmd {data['cmd']} is not supported"
        })

if __name__ == '__main__':
    sio.connect('http://localhost:4000')
    sio.wait()