const express = require('express');
const fs = require('fs');
const path = require('path');
const http = require('http');
const { Server } = require('socket.io');
const config = require('../configs');
const cors = require('cors')

const app = express();
const server = http.createServer(app); 
const io = new Server(server, {
    cors: {
        origin: '*',
    }
})

let PROVIDERS = new Map()
let CLIENTS = new Map()

// setInterval(() => {
//     console.log("=============================================")
//     console.log(`PROVIDERS: ${PROVIDERS.size}`)
//     PROVIDERS.forEach((provider, provider_id) => {
//         console.log(`Provider ${provider_id} is online: ${provider.is_online}`)
//     })

//     console.log(`CLIENTS: ${CLIENTS.size}`)
//     CLIENTS.forEach((client, client_id) => {
//         console.log(`Client ${client_id} is online: ${client.is_online}`)
//     })
//     console.log("=============================================")
// }, 5000)

app.use(cors({
    origin: '*'
}))

app.get('/listAllProvider', (req, res) => {
    return res.json({
        status: "OK",
        message: "List all providers",
        content: Array.from(PROVIDERS.values())
    })
})

app.get('/listAllClient', (req, res) => {
    return res.json({
        status: "OK",
        message: "List all clients",
        content: Array.from(CLIENTS.values())
    })
})

io.on('connection', (socket) => {
    /**
     * Register a kit
     */
    socket.on('register_provider', (payload) => {
        if(!payload || !payload.provider_id) return;
        PROVIDERS.set(payload.provider_id, {
            socket_id: socket.id,
            provider_id: payload.provider_id,
            name: payload.name || '',
            last_seen: new Date().getTime(),
            is_online: true,
            desc: payload.desc || '',
        })
    })

    /**
     * Register a client
     */
    socket.on('register_client', (payload) => {
        if(!payload) return;
        CLIENTS.set(socket.id, {
            username: payload.username,
            user_id: payload.user_id,
            domain: payload.domain,
            last_seen: new Date().getTime(),
            is_online: true,
        })
    })

    socket.on('unregister_client', (payload) => {
        let existClient = CLIENTS.get(socket.id)
        if(existClient) {
            CLIENTS.delete(socket.id)
        }
    })

    /**
     * Handle disconnection
     */
     socket.on('disconnect', () => {
        // --------------------------------------------
        let existProvider = Array.from(PROVIDERS.values()).find(provider => provider.socket_id == socket.id)
        if(existProvider) {
            existProvider.is_online = false
            existProvider.last_seen = new Date().getTime()
        }
        // --------------------------------------------
        let existClient = CLIENTS.get(socket.id)
        if(existClient) {
            CLIENTS.delete(socket.id)
        }
    });

    // ------------ MESSAGE FROM CLIENT TO KIT ----------------
    socket.on('request_provider', (payload) => {
        if(!payload || !payload.cmd || !payload.to_provider_id) return;
        let provider = PROVIDERS.get(payload.to_provider_id)
        // console.log(`provider`, provider)
        if(provider) {
            io.to(provider.socket_id).emit('new_request', {
                request_from: socket.id,
                ...payload
            })
        } else {
            console.log("provider-not-found", payload.to_provider_id)
            socket.emit('server_reply', {
                result: "provider-not-found",
                ...payload
            })
        }
    })

    socket.on('provider_reply', (payload) => {
        if(!payload || !payload.request_from) return;
        io.to(payload.request_from).emit('provider_reply', payload)
    })
});

server.listen(config.port, () => {
    console.log(`Listening on port ${config.port}`);
});
