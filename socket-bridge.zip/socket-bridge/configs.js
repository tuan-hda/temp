const config = {
    port: 4000
}

module.exports = config